

const History = () => {
  return (
    <div>History</div>
  )
}

export default History