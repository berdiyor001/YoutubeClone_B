

const Games = () => {
  return (
    <div>Games</div>
  )
}

export default Games