

const Favourites = () => {
  return (
    <div>Favourites</div>
  )
}

export default Favourites